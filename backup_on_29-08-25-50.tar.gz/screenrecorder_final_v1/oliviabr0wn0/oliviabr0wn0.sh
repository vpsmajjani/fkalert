url=oliviabr0wn0
#url=lulu_moonmoon
cd /home/manish/puppeteer-scraper/flipkart_urls/recorder/$url
node record5working.js https://superchatlive.com/$url
rm /home/manish/puppeteer-scraper/flipkart_urls/recorder/$url/frames/*
