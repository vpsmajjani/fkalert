find /home/manish/puppeteer-scraper/flipkart_urls/recorder/ -type f -name *mp4
find /home/manish/puppeteer-scraper/flipkart_urls/recorder/ -type f -name *mp4 -exec mv {} /home/manish/puppeteer-scraper/flipkart_urls/recorder/clips  \;
