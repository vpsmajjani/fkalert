cd /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BLR-BOM-09-06-2025/
sh /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BLR-BOM-09-06-2025/runme.sh
cd /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BLR-BOM-08-06-2025/
sh /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BLR-BOM-08-06-2025/runme.sh
cd /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BOM-BLR-19-06-2025
sh /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BOM-BLR-19-06-2025/runme.sh
cd /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BLR-BOM-30-08-2025/
sh /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BLR-BOM-30-08-2025/runme.sh
