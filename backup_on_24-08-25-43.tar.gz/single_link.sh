node link.js $1 |grep -oP '"price":\s*\K\d+'
