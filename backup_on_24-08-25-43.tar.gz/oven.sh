sh sc1v1.sh https://www.flipkart.com/voltas-beko-20-l-700-w-smart-solo-microwave-oven/p/itm72f72a1c786e7?pid=MRCG6F5ZTYYQGD8U
sleep 10
sh sc1v1.sh https://www.flipkart.com/samsung-28-l-curd-making-pre-heat-eco-mode-power-defrost-auto-cook-convection-grill-microwave-oven/p/itm16a0a01ca9e79?pid=MRCGDAVXGK9NZWNH
sleep 10
sh sc1v1.sh https://www.flipkart.com/panasonic-23-l-360-degree-heat-wrap-stainless-steel-cavity-magic-grill-express-cooking-convection-microwave-oven/p/itmdwdmnwugfruzy?pid=MRCDWBZX3ZFSPSGH
sleep 10
sh sc1v1.sh https://www.flipkart.com/ifb-23-l-airfryer-multi-stage-cooking-convection-microwave-oven/p/itmdwmvzgvtbzcnz?pid=MRCDWK8TTHVHW3WY
sleep 10
sh sc1v1.sh https://www.flipkart.com/lg-20-l-i-wave-technology-health-plus-indian-cuisine-solo-microwave-oven/p/itmf3rygebb6pbk7?pid=MRCF2UQHF5FPDXGP
sleep 10
sh sc1v1.sh https://www.flipkart.com/samsung-23-l-ceramic-cavity-keep-warm-grill-microwave-oven/p/itm72b04f1b19524?pid=MRCGAEKADP2QKWDH
sleep 10
sh sc1v1.sh https://www.flipkart.com/haier-19-l-inverter-technology-light-weight-defrost-5-power-levels-solo-microwave-oven/p/itm3df8526fcef34?pid=MRCGWV4RQEWV6DHF
sleep 10
sh sc1v1.sh https://www.flipkart.com/panasonic-25-l-solo-microwave-oven/p/itm1206bdf5e05cd?pid=MRCH2GADWPMTGY7S
sleep 10
sh sc1v1.sh https://www.flipkart.com/ifb-30-l-anti-rust-stainless-steel-cavity-360-degree-motorized-rotisserie-express-cooking-childlock-protection-steam-clean-hygiene-convection-microwave-oven/p/itmeftrwhzzy5kyv?pid=MRCEFTRWADS3GCK4
sleep 10
sh sc1v1.sh https://www.flipkart.com/panasonic-20-l-stainless-steel-cavity-solo-microwave-oven/p/itm44af8460a2306?pid=MRCFTZ8EWHBBPCSC
sleep 10
sh sc1v1.sh https://www.flipkart.com/whirlpool-20-l-18-auto-cook-recipes-feather-touch-membrane-solo-microwave-oven/p/itm55e37900bfc42?pid=MRCFHW7R6ZYZPPJT
sleep 10
sh sc1v1.sh https://www.flipkart.com/godrej-20-l-solo-microwave-oven/p/itmdzm9hgcrfrfyp?pid=MRCDZM93AH28HZHZ
sleep 10
sh sc1v1.sh https://www.flipkart.com/lg-28-l-diet-fry-auto-cook-menu-stainless-steel-cavity-pasteurized-milk-360-degree-motorised-rotisserie-bar-be-queing-indian-cuisine-tandoor-se-fry-convection-microwave-oven/p/itmejy9afxsgvzvh?pid=MRCEJY9AF8FJRZTB
sleep 10
sh sc1v1.sh https://www.flipkart.com/panasonic-20-l-epoxy-gray-cavity-coating-auto-cook-recipes-solo-microwave-oven/p/itmb8693e45493f6?pid=MRCFTZ8E2AREQZZ4
sleep 10
sh sc1v1.sh https://www.flipkart.com/lg-32-l-auto-cook-menu-stainless-steel-cavity-360-degree-motorised-rotisserie-bar-be-queing-indian-cuisine-tandoor-se-steam-clean-diet-fry-convection-microwave-oven/p/itmegvvbwfgdfysz?pid=MRCEGVVBVVT8VT8J
sleep 10
sh sc1v1.sh https://www.flipkart.com/lg-20-l-i-wave-technology-indian-cuisine-auto-cook-menu-steam-clean-anti-bacterial-cavity-health-plus-menu-grill-microwave-oven/p/itmdz5v2y3ckyu9y?pid=MRCDZ5VFHGD7F7UV
sleep 10
sh sc1v1.sh https://www.flipkart.com/haier-23-l-900-watt-magnetron-5-power-levels-8-auto-cook-menus-solo-microwave-oven/p/itm258474ec7246b?pid=MRCHFYQCFXUFGTXF
sleep 10
sh sc1v1.sh https://www.flipkart.com/lg-21-l-black-auto-cook-menu-defrost-stainless-steel-cavity-heathplus-indian-cuisine-tandoor-se-paneer-curd-steam-clean-quartz-heater-convection-microwave-oven/p/itmew8zyhmdn8ezp?pid=MRCEW8ZYHPCUW8K9
sleep 10
sh sc1v1.sh https://www.flipkart.com/panasonic-27-l-black-mirror-360-degree-heat-wrap-stainless-steel-cavity-magic-grill-convection-microwave-oven/p/itmegz8zzy66feze?pid=MRCEGZ8Y8X6FNTQU
sleep 10
sh sc1v1.sh https://www.flipkart.com/ifb-20-l-multi-stage-cooking-quick-start-auto-defrost-delay-overheating-protection-solo-microwave-oven/p/itm44436cbe2eb7c?pid=MRCGA9TXFMKFG38U
sleep 10
sh sc1v1.sh https://www.flipkart.com/samsung-23-l-auto-cook-programs-child-safety-lock-memory-feature-deodorization-solo-microwave-oven/p/itm144d023a6b928?pid=MRCGAH4CWJZZ9ZWY
sleep 10
sh sc1v1.sh https://www.flipkart.com/midea-20-l-solo-microwave-oven/p/itmf82bbd44fcd08?pid=MRCH8R8ZVJFDUT5K
sleep 10
sh sc1v1.sh https://www.flipkart.com/samsung-21-l-pre-heat-eco-mode-power-defrost-auto-cook-wire-rack-convection-microwave-oven/p/itm8891a3360f67f?pid=MRCGDAVXQXUHAAHY
sleep 10
sh sc1v1.sh https://www.flipkart.com/panasonic-20-l-grill-microwave-oven/p/itmdwdmnahzgxvyh?pid=MRCDWBZXF5ENWDZB
