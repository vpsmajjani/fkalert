sh sc1v1.sh https://www.flipkart.com/toshiba-c350np-139-cm-55-inch-ultra-hd-4k-led-smart-google-tv-dolby-vision-atmos-regza-engine-zr/p/itm2791f17a0e1f1?pid=TVSHF4RGTWWHQ8DY
sleep 30
sh sc1v1.sh https://www.flipkart.com/doodle-109-cm-43-inch-hd-ready-led-smart-android-tv/p/itm65d86ae26c92f?pid=TVSH58NNPQKQFXYJ
sleep 30
sh sc1v1.sh https://www.flipkart.com/iffalcon-tcl-u64-139-cm-55-inch-ultra-hd-4k-led-smart-google-tv-24w-dolby-audio-hdr10/p/itma839a651fa064?pid=TVSGZK4GUDMN2VVU
sleep 30
sh sc1v1.sh https://www.flipkart.com/thomson-139-cm-55-inch-qled-ultra-hd-4k-smart-google-tv-hdr-10-dolby-atmos-40w-sound-output-dts-trusurround-assistant-dual-band-wi-fi/p/itm70a7a64aa66d3?pid=TVSGHADTWPTJCMP7
sleep 30
sh sc1v1.sh https://www.flipkart.com/tcl-c69b-139-cm-55-inch-qled-ultra-hd-4k-smart-google-tv-dolby-atmos-35w-onkyo-2-1ch-subwoofer/p/itmdfca96c675d49?pid=TVSGZK4GPFF6GMTS
sleep 30
sh sc1v1.sh https://www.flipkart.com/acer-advanced-series-139-cm-55-inch-ultra-hd-4k-led-smart-google-tv-dolby-vision-atmos-36w-sound-output/p/itme648a5f782fc5?pid=TVSGPGXBBY58AH5G
sleep 30
sh sc1v1.sh https://www.flipkart.com/motorola-envisionx-140-cm-55-inch-qled-ultra-hd-4k-smart-google-tv-dolby-vision-atmos/p/itm1cfe8a61a68c5?pid=TVSGSRQ9SXPXPTXJ
sleep 30
sh sc1v1.sh https://www.flipkart.com/redmi-mi-138-cm-55-inch-ultra-hd-4k-led-smart-firetv-os-7-tv-12000-apps-alexa-voice-control-airplay-2-hdr-10-hlg-vivid-picture-engine-30w-dolby-audio-dts-hd-dts-virtual-x/p/itm378269ae9e05b?pid=TVSH4DFYFNVKQHRH
sleep 30
sh sc1v1.sh https://www.flipkart.com/tcl-p71b-pro-139-cm-55-inch-qled-ultra-hd-4k-smart-google-tv-hands-free-voice-control-dolby-vision-atmos-dts-virtual-x-onkyo-2-1ch-120hz-game-accelerator-55p71b-pro/p/itm71cd444d3d11a?pid=TVSGZHYN2MPRSHZV
sleep 30
sh sc1v1.sh https://www.flipkart.com/toshiba-m550mp-139-cm-55-inch-qled-ultra-hd-4k-smart-google-tv-full-array-local-dimming-power-bass-woofer-hsr-120-mode/p/itmb6f937c9a36ce?pid=TVSGSZANYKPX94FC
sleep 30
sh sc1v1.sh https://www.flipkart.com/samsung-new-d-series-brighter-crystal-4k-vision-pro-2024-edition-138-cm-55-inch-ultra-hd-4k-led-smart-tizen-tv-upscaling-multiple-voice-assistance-remote-purcolor-hdr-10-auto-game-mode-q-symphony-knox-security/p/itm8580c5c3990d8?pid=TVSGYWKBJHNSRN9N
sleep 30
sh sc1v1.sh https://www.flipkart.com/toshiba-139-cm-55-inch-qled-ultra-hd-4k-smart-vidaa-tv-dolby-vision-atmos-regza-engine-zr-2024-edition/p/itm2a87eba3d2d05?pid=TVSGZW43FAS2CYPQ
sleep 30
sh sc1v1.sh https://www.flipkart.com/hisense-e6n-139-cm-55-inch-ultra-hd-4k-led-smart-google-tv-dolby-vision-atmos-dts-virtual-x-4k-ai-upscaler/p/itm119ef1d167cd8?pid=TVSHFCA54GEFRHQS
sleep 30
sh sc1v1.sh https://www.flipkart.com/blaupunkt-139-cm-55-inch-qled-ultra-hd-4k-smart-google-tv-60w-sound-output-hdr-10-dolby-atmos-dts-trusurround-assistant-dual-band-wi-fi/p/itm2d49ef5a63a8c?pid=TVSGHADTYYMJHVKX
sleep 30
sh sc1v1.sh https://www.flipkart.com/motorola-envisionx-140-cm-55-inch-ultra-hd-4k-led-smart-google-tv-inbuilt-box-speakers-dolby-audio/p/itm1f2c37bbb8226?pid=TVSGRFZNG6FY3D2S
sleep 30
sh sc1v1.sh https://www.flipkart.com/hisense-e68n-139-cm-55-inch-qled-ultra-hd-4k-smart-google-tv-dolby-vision-atmos-far-field-voice-control-smooth-motion-rate/p/itm8b88693283b3f?pid=TVSHFA9EVDXFPF9M
sleep 30
sh sc1v1.sh https://www.flipkart.com/toshiba-m550lp-series-139-cm-55-inch-qled-ultra-hd-4k-smart-google-tv-bass-woofer-regza-engine/p/itm94a446e9c3195?pid=TVSGFT4SFXP9CYQX
sleep 30
sh sc1v1.sh https://www.flipkart.com/samsung-new-d-series-brighter-crystal-4k-vivid-2024-edition-138-cm-55-inch-ultra-hd-4k-led-smart-tizen-tv-upscaling-purcolor-auto-game-mode-q-symphony-voice-ready-knox-security/p/itm0814962688d12?pid=TVSGYWKBQFHPGMNH
sleep 30
sh sc1v1.sh https://www.flipkart.com/sansui-140-cm-55-inch-qled-ultra-hd-4k-smart-google-tv-ips-display-zen-panel-dolby-vision-atmos-filmmaker-mode/p/itm1fcc576d29fff?pid=TVSGKYNR5C9KHEZK
sleep 30
sh sc1v1.sh https://www.flipkart.com/tcl-v6b-139-cm-55-inch-ultra-hd-4k-led-smart-google-tv-24w-dolby-audio-metallic-bezel-less/p/itm9ee7638cbc059?pid=TVSGZK4GH6FPDYZG
sleep 30
sh sc1v1.sh https://www.flipkart.com/thomson-oathpro-max-139-cm-55-inch-ultra-hd-4k-led-smart-android-tv-dolby-ms12-40w-speakers/p/itm06566b1f40be9?pid=TVSG6P49DH7HWDHP
sleep 30
sh sc1v1.sh https://www.flipkart.com/mi-xiaomi-4x-138-8-cm-55-inch-ultra-hd-4k-led-smart-android-based-tv/p/itm70be32b40e6c4?pid=TVSG22C4CQV6SJPH
sleep 30
sh sc1v1.sh https://www.flipkart.com/hisense-u7n-139-cm-55-inch-ultra-hd-4k-mini-led-smart-vidaa-tv-240-full-array-local-dimming-zones-dolby-vision-atmos/p/itma1d2d206c9c60?pid=TVSHFEMUHTGSJC38
sleep 30
sh sc1v1.sh https://www.flipkart.com/iffalcon-tcl-139-cm-55-inch-qled-ultra-hd-4k-smart-google-tv-dolby-vision-atmos-120-hz-game-accelerator-hands-free-voice-control/p/itmee562361f2a49?pid=TVSGQYX2HHGMVF4U
sleep 30
sh sc1v1.sh https://www.flipkart.com/blaupunkt-cybersound-139-cm-55-inch-ultra-hd-4k-led-smart-android-tv-dolby-ms12-60w-speakers/p/itmb5467eec085bb?pid=TVSG44U6A9TT5K5H
sleep 30
sh sc1v1.sh https://www.flipkart.com/hisense-tornado-139-cm-55-inch-qled-ultra-hd-4k-smart-vidaa-tv/p/itm0ab3cf2377096?pid=TVSGZEHJXCKB9H6G
sleep 30
sh sc1v1.sh https://www.flipkart.com/onida-139-cm-55-inch-ultra-hd-4k-led-smart-vidaa-tv/p/itmc2e079681e949?pid=TVSGC4KJQ58NBZZG
sleep 30
sh sc1v1.sh https://www.flipkart.com/onida-139-cm-55-inch-ultra-hd-4k-led-smart-google-tv-dolby-atmos-vision-hdr10/p/itmc673630198c5e?pid=TVSGQQDYZXWVYVFK
sleep 30
sh sc1v1.sh https://www.flipkart.com/lg-qned-75-139-cm-55-inch-ultra-hd-4k-smart-webos-tv-alpha5-ai-processor-4k-gen6-picture-pro-thinq-ai-60-hz-refresh-rate-game-optimizer-magic-remote-control-5-year-guaranteed-new-os-experience/p/itm49c93f498a0ea?pid=TVSHF3HBHUGNBWJX
sleep 30
sh sc1v1.sh https://www.flipkart.com/lloyd-140-cm-55-inch-qled-ultra-hd-4k-smart-webos-tv/p/itmd0112c90f07a7?pid=TVSGPJYTHTWMQGKZ
sleep 30
sh sc1v1.sh https://www.flipkart.com/aiwa-139-7-cm-55-inch-qled-ultra-hd-4k-smart-google-tv-1n-remot-control-4n-screw-1n-user-manual-warranty-card-set-table-stand-wallmount-2n-batteries-aaa/p/itmc164ea3a7adfc?pid=TVSH5M5GG8GX7RWX
sleep 30
sh sc1v1.sh https://www.flipkart.com/acer-v-series-139-cm-55-inch-qled-ultra-hd-4k-smart-google-tv/p/itmc8f3ef84dd17a?pid=TVSGRDKGZPNYUPTV
sleep 30
sh sc1v1.sh https://www.flipkart.com/samsung-138-cm-55-inch-ultra-hd-4k-led-smart-tizen-tv/p/itm91f4fde735594?pid=TVSGYWKBVSABPEGF
sleep 30
sh sc1v1.sh https://www.flipkart.com/hisense-u6k-139-cm-55-inch-qled-ultra-hd-4k-smart-google-tv-full-array-local-dimming-hands-free-voice-control-dolby-vision-atmos-55u6k/p/itmd0f831df4af49?pid=TVSGUEAAVWDG8BRK
sleep 30
sh sc1v1.sh https://www.flipkart.com/lloyd-140-cm-55-inch-ultra-hd-4k-led-smart-android-tv/p/itm964bf4419575b?pid=TVSGC8TQWAZJMZWE
sleep 30
sh sc1v1.sh https://www.flipkart.com/samsung-oled-139-7-cm-55-inch-ultra-hd-4k-smart-tizen-tv/p/itm74f3ac029327e?pid=TVSGYSPNYRGMNDDK
sleep 30
sh sc1v1.sh https://www.flipkart.com/hisense-tornado-139-cm-55-inch-ultra-hd-4k-led-smart-google-tv-built-in-jbl-soundbar-25w-subwoofer-120-high-refresh-rate-mode/p/itmdc68a784fb341?pid=TVSGQSEMPZHYYA2E
sleep 30
sh sc1v1.sh https://www.flipkart.com/samsung-neo-qled-138-cm-55-inch-ultra-hd-4k-smart-tizen-tv/p/itm9f66fc38b0a65?pid=TVSGZYKS7S5EGGYX
sleep 30
sh sc1v1.sh https://www.flipkart.com/tcl-c755-139-cm-55-inch-ultra-hd-4k-mini-led-smart-google-tv-144hz-vrr-imax-enhanced/p/itm50967472818a0?pid=TVSGXECUSAVWBJBY
sleep 30
sh sc1v1.sh https://www.flipkart.com/samsung-138-cm-55-inch-ultra-hd-4k-led-smart-tizen-tv/p/itm7012e1dcd180e?pid=TVSGYWKBEN7BUUJN
sleep 30
