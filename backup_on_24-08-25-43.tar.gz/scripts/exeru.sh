sh /home/manish/puppeteer-scraper/flipkart_urls/bulkproduct/products/executeshfiles.sh
sh /home/manish/puppeteer-scraper/flipkart_urls/products/executeshfiles.sh
