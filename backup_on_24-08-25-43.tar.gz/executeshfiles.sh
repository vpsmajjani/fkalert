cd /home/manish/puppeteer-scraper/flipkart_urls/products
for d in */; do (cd "$d" && bash *.sh); done
