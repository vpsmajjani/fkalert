sh sc1v1.sh https://www.flipkart.com/crompton-88-l-desert-air-cooler-honeycomb-cooling-pad/p/itm295301ffdc909?pid=AICFFVVJFQHHNCN8
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-75-l-desert-air-cooler/p/itmfdzqqxypamuz9?pid=AICEQGBHB75HSWGG
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-100-l-desert-air-cooler-motor-overload-protection-auto-drain/p/itmb45340b62127b?pid=AICFZ48HGYPPNPPP
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-40-l-room-personal-air-cooler/p/itme1e2a77c15f3e?pid=AICFQV87NFUG595H
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-65-l-desert-air-cooler-motor-overload-protection-collapsible-louvers/p/itm0a4d7e40593b7?pid=AICFEGG4KWEQVYDH
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-125-l-desert-air-cooler/p/itm90ab05dac0c82?pid=AICGKB3HNZF9K6SH
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-75-l-desert-air-cooler/p/itma923a365b7aff?pid=AICGKB3HXETYHVFA
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-90-l-desert-air-cooler/p/itm8066b274d3238?pid=AICGBE5FKTBBQDYG
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-43-l-desert-air-cooler/p/itmdd05de57e2380?pid=AICGBE5F6FQNHNVT
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-95-l-desert-air-cooler/p/itmacca1863d2a2a?pid=AICGXE4FMNVUNXWY
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-88-l-desert-air-cooler/p/itm295301ffdc909?pid=AICGNB2GQDADSHHR
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-88-l-desert-air-cooler/p/itm295301ffdc909?pid=AICFQEWHYAN5ZCZP
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-52-l-tower-air-cooler/p/itm7b8d72f4d48f5?pid=AICFZ48H6GD5VEGN
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-10-l-tower-air-cooler/p/itm183e3f22fd7e5?pid=AICGHK53E2RXV2JV
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-43-l-desert-air-cooler/p/itm3a77a773875c9?pid=AICGYVA69VUQZEPA
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-40-l-room-personal-air-cooler/p/itme1e2a77c15f3e?pid=AICGCCP9ZHAG2UTY
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-100-l-desert-air-cooler/p/itmb45340b62127b?pid=AICGY7JGGC85QZD9
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-88-l-desert-air-cooler/p/itm4011b974dc36b?pid=AICGKB3HWXR3HFJH
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-35-l-tower-air-cooler/p/itm6bd5f3b42415f?pid=AICFZ48HPG6A49J6
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-24-l-tower-air-cooler/p/itm4900a0626ea30?pid=AICHFFG56Q4SM9AJ
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-60-l-desert-air-cooler/p/itma36dc05eecc51?pid=AICGBE5FJG6B29X5
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-54-l-window-air-cooler/p/itm90903009a8c91?pid=AICGBE5FZCJWU6PZ
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-40-l-room-personal-air-cooler/p/itmad7257a1fcfe8?pid=AICHFCB7S5YW6TKK
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-100-l-desert-air-cooler/p/itmfdwa95yeshx4x?pid=AICGETHFNCZCX7PA
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-135-l-desert-air-cooler/p/itm99bc4ecd403a7?pid=AICGYBNMVNTFNTCU
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-75-l-desert-air-cooler/p/itmfdzqqxypamuz9?pid=AICFQEWHES9VS6VY
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-34-l-tower-air-cooler/p/itm717e0d98f4ea9?pid=AICHFEJ2UQQCJSPN
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-90-l-room-personal-air-cooler/p/itm8066b274d3238?pid=AICGXKWDSZZYR3VP
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-55-l-desert-air-cooler/p/itm92528ff11bf0a?pid=AICGKB3HF7ZUD5P5
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-35-l-tower-air-cooler/p/itm6bd5f3b42415f?pid=AICGCAKGYQGXSGAQ
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-65-l-desert-air-cooler/p/itm77143234b8a2f?pid=AICGXE4FG8MAUQBF
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-125-l-desert-air-cooler/p/itmdcc79176ab67e?pid=AICGNMDUMCPQ8NV9
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-50-l-desert-air-cooler/p/itm6f9c463c70521?pid=AICFPZZRNQQGWN6F
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-90-l-desert-air-cooler/p/itm5ac257abc8b54?pid=AICGEYY9RZS4ZJXH
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-100-l-desert-air-cooler/p/itma7475d3164171?pid=AICGXE4FGRKSD4DX
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-23-l-room-personal-air-cooler/p/itm6022974eedce9?pid=AICFQV87WNT64CJQ
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-65-l-desert-air-cooler/p/itmb8e5dac1e7be9?pid=AICG2BJXHUVH9ZVP
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-75-l-desert-air-cooler/p/itm491f372915fbc?pid=AICGY73CZ47FB6ZY
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-35-l-room-personal-air-cooler/p/itm5f603d70afd20?pid=AICGBUNTQSSA2H5Z
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-27-l-tower-air-cooler/p/itma0e2851e27a4a?pid=AICFZ48HVWZS2U3V
