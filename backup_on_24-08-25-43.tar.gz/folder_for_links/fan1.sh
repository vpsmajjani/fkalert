sh sc1v1.sh https://www.flipkart.com/atomberg-renesa-prime-remote-5-star-1200-mm-3-blade-ceiling-fan/p/itm7c72f96e8deb9?pid=FANGX24EM7D84EKJ
sleep 10
sh sc1v1.sh https://www.flipkart.com/atomberg-renesa-prime-remote-5-star-1200-mm-3-blade-ceiling-fan/p/itm29aec46ccf9a2?pid=FANH743FXESX6CP6
sleep 10
sh sc1v1.sh https://www.flipkart.com/atomberg-efficio-alpha-35w-energy-saving-1-1-warranty-5-star-1200-mm-3-blade-ceiling-fan/p/itm65b8e7583cbb7?pid=FANHFPVYPMJUBN5Z
sleep 10
sh sc1v1.sh https://www.flipkart.com/atomberg-ameza-ceiling-fan-5-star-1200-mm-3-blade/p/itm3a39e531aebf0?pid=FANGZ6MQBHWDCBZ5
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-energion-hyperjet-5-star-1200-mm-3-blade-ceiling-fan/p/itm415cef71fa427?pid=FANGQFKMH2UTGC4Z
sleep 10
sh sc1v1.sh https://www.flipkart.com/orient-electric-ujala-prime-5-star-1200-mm-3-blade-ceiling-fan/p/itm5d28c8311bbd2?pid=FANGTBF8Z2DBZZHR
sleep 10
sh sc1v1.sh https://www.flipkart.com/atomberg-renesa-prime-remote-5-star-1200-mm-3-blade-ceiling-fan/p/itmd99e0d2c45ce2?pid=FANGX23S6BYWDQK6
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-energion-hyperjet-5-star-1200-mm-3-blade-ceiling-fan/p/itm3a71c2ca6ad1e?pid=FANGQFKGPPBCDBZF
sleep 10
sh sc1v1.sh https://www.flipkart.com/atomberg-renesa-prime-remote-5-star-1200-mm-3-blade-ceiling-fan/p/itmb67b59402a728?pid=FANGX234NUQNWVZJ
sleep 10
sh sc1v1.sh https://www.flipkart.com/atomberg-renesa-ceiling-fan-5-star-1200-mm-3-blade/p/itmdabb9ebcdf96e?pid=FANFAWU9DBJS6GY2
sleep 10
sh sc1v1.sh https://www.flipkart.com/atomberg-studio-35w-energy-saving-2-1-warranty-5-star-1200-mm-3-blade-ceiling-fan/p/itmd7bb5acf5aadd?pid=FANFQJYSG5PU3AQF
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-energion-hyperjet-5-star-1200-mm-3-blade-ceiling-fan/p/itmf28deed27e178?pid=FANGQ5YKHBFUZWKX
sleep 10
sh sc1v1.sh https://www.flipkart.com/polycab-wizzy-neo-led-1200mm-5-star-bldc-remote-8-purple-speed-indicator-5-star-1200-mm-3-blade-ceiling-fan/p/itm17ce84d8549fb?pid=FANH82JGAMQ4CNCV
sleep 10
sh sc1v1.sh https://www.flipkart.com/atomberg-renesa-ceiling-fan-5-star-1200-mm-3-blade/p/itmb887b1fc0a61c?pid=FANFAWU6MZGZ7XUG
sleep 10
sh sc1v1.sh https://www.flipkart.com/atomberg-renesa-prime-remote-5-star-1200-mm-3-blade-ceiling-fan/p/itm0966531e53c2b?pid=FANH742V7ZHA8H7Z
sleep 10
sh sc1v1.sh https://www.flipkart.com/candes-phantom-led-light-5-star-1200-mm-6-blade-ceiling-fan/p/itm2ac49f41ba411?pid=FANHYZ2PYKPV43JP
sleep 10
sh sc1v1.sh https://www.flipkart.com/activa-gracia-1200-mm-3-blade-ceiling-fan/p/itmad59eb397f666?pid=FANGQHGHAPXW8JAJ
sleep 10
sh sc1v1.sh https://www.flipkart.com/digismart-autum-mark-1-380-rpm-high-speed-28watt-led-light-inverter-technology-5-star-1200-mm-3-blade-ceiling-fan/p/itmd9775a8bb5f19?pid=FANGW5J7UVHBDPEG
sleep 10
sh sc1v1.sh https://www.flipkart.com/orient-electric-ujala-prime-5-star-1200-mm-3-blade-ceiling-fan/p/itmbac07cc27191f?pid=FANGTBF8GNTGAZQK
sleep 10
sh sc1v1.sh https://www.flipkart.com/zuvuzu-high-speed-rechargeable-table-fan-led-light-home-office-kitchen-5-star-1400-mm-3-blade/p/itm9677f9d8e80c7?pid=FANHA2XNKMUDM3WR
sleep 10
sh sc1v1.sh https://www.flipkart.com/orient-electric-kratos-neu-5-star-1200-mm-3-blade-ceiling-fan/p/itmc53b81e6c6806?pid=FANH8RYSFWTSADQH
sleep 10
sh sc1v1.sh https://www.flipkart.com/atomberg-renesa-smart-fan-5-star-1200-mm-3-blade-ceiling/p/itme3672da5315d7?pid=FANGZF9EGEVNMGBP
sleep 10
sh sc1v1.sh https://www.flipkart.com/havells-ambrose-slim-5-star-1200-mm-3-blade-ceiling-fan/p/itmbc9a4477e5b42?pid=FANGYYSET8YVAPQY
sleep 10
sh sc1v1.sh https://www.flipkart.com/candes-ecobreeze-5-star-1200-mm-4-blade-ceiling-fan/p/itm40906f505b9f7?pid=FANHFZQU5KGF5JZU
sleep 10
