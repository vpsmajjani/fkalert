cd /home/manish/puppeteer-scraper/flipkart_urls
git add .
git commit -m "adding updated files"
git push
