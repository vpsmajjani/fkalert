sh /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BOM-BLR-16-05-2025/runme.sh >>/tmp/flight_BOM-BLR-16-05-2025.txt 2>&1
sh  /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BOM-BLR-17-05-2025/runme.sh >>/tmp/flight_BOM-BLR-17-05-2025.txt 2>&1
sh  /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BOM-BLR-18-05-2025/runme.sh >>/tmp/flight_BOM-BLR-18-05-2025.txt 2>&1
#sh  /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BLR-BOM-25-04-2025/runme.sh >>/tmp/flight_BLR-BOM-25-04-2025.txt 2>&1
sh  /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BOM-BLR-01-07-2025/runme.sh >>/tmp/flight_BOM-BLR-01-07-2025.txt 2>&1
sh  /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BOM-BLR-30-06-2025/runme.sh >>/tmp/flight_BOM-BLR-30-06-2025.txt 2>&1
sh  /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BLR-BOM-30-06-2025/runme.sh >>/tmp/flight_BLR-BOM-30-06-2025.txt 2>&1
sh  /home/manish/puppeteer-scraper/flipkart_urls/recorder/flight/BLR-BOM-01-07-2025/runme.sh >>/tmp/flight_BLR-BOM-01-07-2025.txt 2>&1
