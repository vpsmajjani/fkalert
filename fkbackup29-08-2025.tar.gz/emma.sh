
cd /home/manish/puppeteer-scraper/flipkart_urls/
url=Emma_adorablle
node record5working.js https://superchatlive.com/$url
rm /home/manish/puppeteer-scraper/flipkart_urls/frames/
