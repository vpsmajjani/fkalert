print(100)
print("manish")

print (10/10)
print(f'sum of two number is {10+10}')


lenght = 30
width = 20
name = 'manish'
print(name,lenght)
print(lenght * width)
print(f'area of react {lenght * width}')


mybo = True

num1 = 10
num2 = '10'
#print(num1+num2)
print(type(num1))

print(type(num2))

print(type(mybo))


print(2**5)


f_name = 'printo'
l_name = 'canvera'
full_name = f_name + ' ' +l_name
print(full_name)
