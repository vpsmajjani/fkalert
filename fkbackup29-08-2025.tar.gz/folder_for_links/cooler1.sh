sh sc1v1.sh https://www.flipkart.com/rr-40-l-room-personal-air-cooler/p/itm15e7a72651a99?pid=AICGYFGXMSTBHJKQ
sleep 10
sh sc1v1.sh https://www.flipkart.com/rr-70-l-desert-air-cooler/p/itm7189f48ac71c5?pid=AICGYFGVHKCF67NH
sleep 10
sh sc1v1.sh https://www.flipkart.com/bajaj-24-l-room-personal-air-cooler/p/itm35674228b8dea?pid=AICGXHWYMHFVEDSQ
sleep 10
sh sc1v1.sh https://www.flipkart.com/bajaj-90-l-desert-air-cooler/p/itm44740af995797?pid=AICGYZGHPHH7G9VE
sleep 10
sh sc1v1.sh https://www.flipkart.com/hindware-smart-appliances-85-l-desert-air-cooler/p/itm2d93d3bce627a?pid=AICERF3ZMFAYK4ZC
sleep 10
sh sc1v1.sh https://www.flipkart.com/kenstar-60-l-desert-air-cooler/p/itm8bebd42a702c3?pid=AICFZ3MTCTRJKVYG
sleep 10
sh sc1v1.sh https://www.flipkart.com/flipkart-smartbuy-95-l-desert-air-cooler/p/itmcfc9f808ad8f4?pid=AICFZHF7RQHHZNQH
sleep 10
sh sc1v1.sh https://www.flipkart.com/thomson-105-l-desert-air-cooler/p/itmc67065149aca4?pid=AICGYFKUAEGHXFJZ
sleep 10
sh sc1v1.sh https://www.flipkart.com/hindware-smart-appliances-45-l-room-personal-air-cooler/p/itmb48940998bd87?pid=AICGYH26HGMFGEBF
sleep 10
sh sc1v1.sh https://www.flipkart.com/kenstar-45-l-room-personal-air-cooler/p/itmad6ad8cafa2ee?pid=AICH893NGDBPTPKH
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-40-l-room-personal-air-cooler/p/itme1e2a77c15f3e?pid=AICFQV87NFUG595H
sleep 10
sh sc1v1.sh https://www.flipkart.com/bajaj-36-l-room-personal-air-cooler/p/itmf3j9zyckqvfpg?pid=AICDHACRZG6ZSYZH
sleep 10
sh sc1v1.sh https://www.flipkart.com/voltas-36-l-room-personal-air-cooler/p/itmd37d23259f8bc?pid=AICGN8KAZNPAQ6YW
sleep 10
sh sc1v1.sh https://www.flipkart.com/hindware-smart-appliances-50-l-desert-air-cooler/p/itmd9f68ae7c30bb?pid=AICFERMY7WWWAZYZ
sleep 10
sh sc1v1.sh https://www.flipkart.com/kenstar-27-l-room-personal-air-cooler/p/itmd633a0eaadd86?pid=AICGX23F9JEJWXDH
sleep 10
sh sc1v1.sh https://www.flipkart.com/orient-electric-85-l-desert-air-cooler-aerofan-technology-densenest-honeycomb-design/p/itm88a7e1ae58828?pid=AICGF8KFFAPSZJES
sleep 10
sh sc1v1.sh https://www.flipkart.com/kenstar-60-l-window-air-cooler/p/itm3941b293062d7?pid=AICH8A9FSPHCTSYF
sleep 10
sh sc1v1.sh https://www.flipkart.com/flipkart-smartbuy-75-l-desert-air-cooler/p/itmfe94c84bf7a15?pid=AICFZHF7SBYHEMHJ
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-75-l-desert-air-cooler/p/itmfdzqqxypamuz9?pid=AICEQGBHB75HSWGG
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-88-l-desert-air-cooler-honeycomb-cooling-pad/p/itm295301ffdc909?pid=AICFFVVJFQHHNCN8
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-88-l-desert-air-cooler/p/itm4011b974dc36b?pid=AICGKB3HWXR3HFJH
sleep 10
sh sc1v1.sh https://www.flipkart.com/symphony-27-l-room-personal-air-cooler/p/itmfyp69az7wjdtv?pid=AICFFGJZTHSDN3AZ
sleep 10
sh sc1v1.sh https://www.flipkart.com/bajaj-36-l-room-personal-air-cooler/p/itmf3j9zyckqvfpg?pid=AICGAYB3S8J2SSVS
sleep 10
sh sc1v1.sh https://www.flipkart.com/voltas-90-l-desert-air-cooler/p/itme34b63b3af844?pid=AICGN8KAJGZAPYF5
sleep 10
sh sc1v1.sh https://www.flipkart.com/voltas-55-l-desert-air-cooler/p/itm65b729bb9d482?pid=AICFEHYGPSYTWD93
sleep 10
sh sc1v1.sh https://www.flipkart.com/symphony-95-l-desert-air-cooler/p/itmc1e7b61153c4b?pid=AICGWK4XTMHHFBHU
sleep 10
sh sc1v1.sh https://www.flipkart.com/flipkart-smartbuy-55-l-room-personal-air-cooler/p/itmfe3zhh3svzf5y?pid=AICH7NFUGUNYZCHB
sleep 10
sh sc1v1.sh https://www.flipkart.com/thomson-40-l-room-personal-air-cooler/p/itm2fc46d6d69a55?pid=AICH98XJDMHJHHRX
sleep 10
sh sc1v1.sh https://www.flipkart.com/flipkart-smartbuy-60-l-desert-air-cooler/p/itmf847e58d579ca?pid=AICFZHF7FJAHYXHK
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-100-l-desert-air-cooler-motor-overload-protection-auto-drain/p/itmb45340b62127b?pid=AICFZ48HGYPPNPPP
sleep 10
sh sc1v1.sh https://www.flipkart.com/kenstar-90-l-desert-air-cooler/p/itm75e75cdd1025a?pid=AICGMB7GB7ZZYVMA
sleep 10
sh sc1v1.sh https://www.flipkart.com/thomson-150-l-desert-air-cooler/p/itmfb78e23822b3e?pid=AICGYFKUFEEUE6EE
sleep 10
sh sc1v1.sh https://www.flipkart.com/thomson-115-l-desert-air-cooler/p/itm2665b2c946953?pid=AICGYFKUYPEGRBPR
sleep 10
sh sc1v1.sh https://www.flipkart.com/thomson-28-l-room-personal-air-cooler/p/itmd08998b66ca00?pid=AICGYFKUAYGQZNGA
sleep 10
sh sc1v1.sh https://www.flipkart.com/orient-electric-90-l-desert-air-cooler/p/itm959a74969ca8f?pid=AICGWFW6ZCMBTVYG
sleep 10
sh sc1v1.sh https://www.flipkart.com/orient-electric-50-l-window-air-cooler/p/itmeqvhufheqhztw?pid=AICEQVHUGDDBYF6K
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-95-l-desert-air-cooler/p/itmacca1863d2a2a?pid=AICGXE4FMNVUNXWY
sleep 10
sh sc1v1.sh https://www.flipkart.com/crompton-75-l-desert-air-cooler/p/itma923a365b7aff?pid=AICGKB3HXETYHVFA
sleep 10
sh sc1v1.sh https://www.flipkart.com/bajaj-42-l-room-personal-air-cooler/p/itm6f2f9370b9079?pid=AICH8MJ29PNYZFFW
sleep 10
sh sc1v1.sh https://www.flipkart.com/kenstar-27-l-room-personal-air-cooler/p/itm75e4783e905eb?pid=AICH895DGGBZXXHY
