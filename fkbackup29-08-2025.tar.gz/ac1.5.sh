sh sc1v1.sh https://www.flipkart.com/samsung-2025-model-bespoke-ai-5-step-convertible-1-5-ton-3-star-split-inverter-powerful-cooling-energy-saving-120-expandable-ac-wi-fi-connect-white/p/itm5c1ad82bd595b?pid=ACNH7SAPGZZCDTDN
sleep 10
sh sc1v1.sh https://www.flipkart.com/godrej-2025-model-5-in-1-convertible-cooling-1-5-ton-3-star-split-inverter-heavy-duty-pure-air-filter-ac-white/p/itmd5626850d65b9?pid=ACNH7SAZTYJ4JY3D
sleep 10
sh sc1v1.sh https://www.flipkart.com/panasonic-2025-model-1-5-ton-5-star-split-inverter-ac-wi-fi-connect-white/p/itm7804282bcdfb5?pid=ACNH8EYXHDFAREWW
sleep 10
sh sc1v1.sh https://www.flipkart.com/panasonic-2025-model-1-5-ton-3-star-split-inverter-ac-wi-fi-connect-white/p/itm1844c2c2e8a54?pid=ACNH8EYXXMGGSGKR
sleep 10
sh sc1v1.sh https://www.flipkart.com/voltas-2024-model-1-5-ton-3-star-split-inverter-ac-white/p/itmee86accb4f614?pid=ACNGYPU5FPG9ZSJM
sleep 10
sh sc1v1.sh https://www.flipkart.com/lloyd-1-5-ton-3-star-split-inverter-ac-white/p/itm0d2649c74e8fa?pid=ACNGYXNMMHPSYNK5
sleep 10
sh sc1v1.sh https://www.flipkart.com/ifb-2025-model-silver-plus-series-1-5-ton-3-star-split-inverter-hd-compressor-ai-dual-gold-fin-nano-tek-coating-8-in-1-flexi-mode-ac-white/p/itm2622e1fc80d88?pid=ACNH89DZMGW9QSWK
sleep 10
sh sc1v1.sh https://www.flipkart.com/panasonic-2024-model-7-1-convertible-true-ai-mode-1-5-ton-3-star-split-inverter-ac-wi-fi-connect-white/p/itm8db3b61a7a0b2?pid=ACNGXYZYWHQVSGZT
sleep 10
sh sc1v1.sh https://www.flipkart.com/samsung-2025-model-bespoke-ai-5-step-convertible-1-5-ton-star-split-inverter-powerful-cooling-energy-saving-120-expandable-ac-wi-fi-connect-white/p/itm5c1ad82bd595b?pid=ACNH7SAPXC4HEZEY
sleep 10
sh sc1v1.sh https://www.flipkart.com/marq-flipkart-2025-1-5-ton-3-star-split-inverter-5-in-1-convertible-turbo-cool-technology-ac-white/p/itmfd8dfe14ce4f5?pid=ACNH76Z3W5YGCTSM
sleep 10
sh sc1v1.sh https://www.flipkart.com/daikin-2023-model-1-5-ton-3-star-split-inverter-ac-pm-2-5-filter-white/p/itm4d9c0889981a6?pid=ACNGFSYTSYRUQUSZ
sleep 10
sh sc1v1.sh https://www.flipkart.com/godrej-2025-model-1-5-ton-5-star-split-inverter-heavy-duty-cooling-extreme-temperature-ac-white/p/itmc44f73de67e87?pid=ACNH8EXUCPYYFZNG
sleep 10
sh sc1v1.sh https://www.flipkart.com/lg-2025-model-ai-convertible-6-in-1-1-5-ton-3-star-split-dual-inverter-faster-cooling-energy-saving-viraat-mode-diet-plus-ac-white/p/itm5d38061f6a915?pid=ACNH7SB8HTAJF85N
sleep 10
sh sc1v1.sh https://www.flipkart.com/lloyd-1-5-ton-5-star-split-inverter-ac-white/p/itm2c5454bf72d11?pid=ACNGZEHFHENV5JYF
sleep 10
sh sc1v1.sh https://www.flipkart.com/carrier-2025-model-6-1-convertible-1-5-ton-3-star-split-inverter-ac-wi-fi-connect-white/p/itm31effe21fee5b?pid=ACNH8NPZEGVGS5EE
sleep 10
sh sc1v1.sh https://www.flipkart.com/carrier-2025-model-6-1-convertible-1-5-ton-5-star-split-inverter-ac-wi-fi-connect-white/p/itm31effe21fee5b?pid=ACNH8NPZMUKYEEGP
sleep 10
sh sc1v1.sh https://www.flipkart.com/godrej-5-in-1-convertible-cooling-2024-model-1-5-ton-3-star-split-inverter-heavy-duty-extreme-temperature-ac-white/p/itmd5efd8d1ef030?pid=ACNHFAA4RZGFDABF
sleep 10
sh sc1v1.sh https://www.flipkart.com/samsung-2025-model-windfree-technology-bespoke-ai-5-step-convertible-1-5-ton-3-star-split-inverter-powerful-cooling-energy-saving-120-expandable-ac-wi-fi-connect-white/p/itm07cce3411a80e?pid=ACNH7SAPYKWRQPK9
sleep 10
sh sc1v1.sh https://www.flipkart.com/voltas-2024-model-1-5-ton-5-star-split-inverter-ac-white/p/itm877e7eb0fb7fb?pid=ACNGYPU5ASZ2TAYA
sleep 10
sh sc1v1.sh https://www.flipkart.com/marq-flipkart-2025-1-5-ton-5-star-split-inverter-5-in-1-convertible-turbo-cool-technology-ac-white/p/itmfd8dfe14ce4f5?pid=ACNH76Z3PR5JJ9YH
sleep 10
sh sc1v1.sh https://www.flipkart.com/godrej-5-in-1-convertible-2024-model-1-5-ton-5-star-split-inverter-heavy-duty-cooling-extreme-temperature-ac-white/p/itm22254bbefbc1d?pid=ACNGYKCDQWYSX27Z
sleep 10
sh sc1v1.sh https://www.flipkart.com/godrej-5-in-1-convertible-2024-model-1-5-ton-4-star-split-inverter-way-air-swing-heavy-duty-cooling-extreme-temperature-ac-white/p/itm1d55bc7aa1c4c?pid=ACNGYWSEF847MT4Z
sleep 10
sh sc1v1.sh https://www.flipkart.com/lg-2025-mode-ai-convertible-6-in-1-1-5-ton-5-star-split-dual-inverter-faster-cooling-energy-saving-4-way-air-swing-viraat-diet-plus-ac-white/p/itm5d38061f6a915?pid=ACNH7SB8EYTBFD2A
sleep 10
sh sc1v1.sh https://www.flipkart.com/carrier-2025-model-1-5-ton-4-star-split-inverter-ac-white/p/itm9105665d72816?pid=ACNH8NPZZTNZYYWX
