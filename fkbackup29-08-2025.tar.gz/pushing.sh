echo "opening path"
cd /workspaces/fkalert/
git init .
git add .
git commit -m "auto commit"
echo "commit success"
git push
